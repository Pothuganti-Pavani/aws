myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
myFruitList[2] = "orange"
print(myFruitList)
biscuits=["oreo", "krack jack", "monaco"] 
print(biscuits)
print(type(biscuits))
print(biscuits[0])
print(biscuits[1])
print(biscuits[2])
myFavoritegame = {
  "Pavani" : "kabaddi",
  "kiranmai" : "Kho-Kho",
  "Swathi" : "Cricket"
}
print(myFavoritegame)
print(type(myFavoritegame))